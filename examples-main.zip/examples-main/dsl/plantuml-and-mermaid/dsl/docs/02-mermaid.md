## Mermaid example

```mermaid
graph TD;
    A-->B;
    A-->C;
    B-->D;
    C-->D;
```