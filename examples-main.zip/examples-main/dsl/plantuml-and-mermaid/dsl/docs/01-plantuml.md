## PlantUML example

```plantuml
Bob->Alice : Hello!
```
