# Structurizr DSL

This directory contains some examples to demonstrate the various features of Structurizr when using the Structurizr DSL.