package org.example.backstage;

public class EntitySpec {

    public String owner;
    public String domain;
    public String system;
    public String type;

}