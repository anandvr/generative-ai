package org.example.backstage;

public class EntityMetadata {

    public String namespace;
    public String name;
    public String description;
    public String[] tags;

}