package org.example.backstage;

public class Relation {

    public String type;
    public String targetRef;

}