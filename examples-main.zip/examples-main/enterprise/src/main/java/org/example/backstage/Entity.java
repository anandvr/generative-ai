package org.example.backstage;

public class Entity {

    public String kind;
    public EntityMetadata metadata;
    public EntitySpec spec;
    public Relation[] relations;

}